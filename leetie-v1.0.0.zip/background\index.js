var w=Object.defineProperty;var E=(n,e,t)=>e in n?w(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var f=(n,e,t)=>E(n,typeof e!="symbol"?e+"":e,t);import{L as T,s as c,i as P}from"../assets/storage-DdR7JFBK.js";import{GitHubService as d}from"../assets/github.service-CoyREgGN.js";class y{static getHeaders(e){return{Authorization:`Bearer ${e}`,Accept:"application/vnd.github.v3+json","Content-Type":"application/json","User-Agent":"leetie-extension"}}static toBase64(e){return btoa(unescape(encodeURIComponent(e)))}static getExtension(e){const t=e.toLowerCase().trim();return T[t]||"txt"}static formatFilePath(e,t){const{problem:i,lang:o}=e,s=this.getExtension(o),r=String(i.id).padStart(4,"0"),a=t.solutionSubfolder||"solutions";return t.preferredDirFormat==="flat"?`${a}/${r}-${i.slug}/solution.${s}`:`${a}/${i.difficulty}/${r}-${i.slug}/solution.${s}`}static formatSolutionHeader(e){const{problem:t,lang:i,runtime:o,memory:s,runtimePercentile:r,memoryPercentile:a}=e,u=`https://leetcode.com/problems/${t.slug}/`,m=t.topicTags.length>0?t.topicTags.join(", "):"N/A",l=["html","xml"].includes(this.getExtension(i))?"<!--":"#",h=["html","xml"].includes(this.getExtension(i))?"-->":"";return`${l} ──────────────────────────────────────────────────
${l} Problem  : ${t.id}. ${t.title}
${l} Difficulty: ${t.difficulty}
${l} Tags     : ${m}
${l} Link     : ${u}
${l} Runtime  : ${o} (beats ${r}%)
${l} Memory   : ${s} (beats ${a}%)
${l} Language : ${i}
${l} Synced by: leetie
${l} ────────────────────────────────────────────────── ${h}

${e.code}`}static async getFileSha(e,t,i,o,s){try{const r=await fetch(`${this.BASE_URL}/repos/${t}/${i}/contents/${o}?ref=${s}`,{headers:this.getHeaders(e)});if(r.ok)return(await r.json()).sha||null}catch(r){console.warn(`[leetie] Error checking SHA for ${o}:`,r)}return null}static async putFile(e,t,i,o,s,r,a){var p,b;const u=await this.getFileSha(e,t,i,o,a),m={message:r,content:this.toBase64(s),branch:a};u&&(m.sha=u);const l=await fetch(`${this.BASE_URL}/repos/${t}/${i}/contents/${o}`,{method:"PUT",headers:this.getHeaders(e),body:JSON.stringify(m)});if(!l.ok){const $=await l.json().catch(()=>({}));throw new Error($.message||`GitHub Commit Failed (${l.status})`)}const h=await l.json();return((p=h.content)==null?void 0:p.sha)||((b=h.commit)==null?void 0:b.sha)||"success"}static generateReadmeContent(e,t){const i=t.solutionSubfolder||"solutions",o=e.map(s=>{const r=`https://leetcode.com/problems/${s.problemSlug}/`,a=`./${s.githubPath.replace(`${i}/`,"")}`;return`| ${s.problemSlug} | ${s.problemTitle} | ${s.difficulty} | ${s.lang} | [Problem](${r}) | [Solution](${a}) |`}).join(`
`);return`# My LeetCode Solutions

> *Automatically synced by [leetie](https://github.com/Shreeprasandh/leetie).*

## Progress Summary: ${e.length} Solved

| ID | Problem | Difficulty | Language | Problem Link | Solution Code |
|---|---------|-----------|----------|--------------|---------------|
${o}
`}static async commitSubmission(e){const t=await c.getConfig();if(!t.githubToken||!t.githubUsername)throw new Error("GitHub token or username not configured. Please open leetie options.");await d.ensureRepo(t.githubToken,t.githubUsername,t.repoName);const i=this.formatFilePath(e,t),o=t.addHeaderComment?this.formatSolutionHeader(e):e.code,s=`leetie: Add ${e.problem.id}. ${e.problem.title} [${e.problem.difficulty}] (${e.lang})`,r=await this.putFile(t.githubToken,t.githubUsername,t.repoName,i,o,s,t.branch),a={submissionId:e.submissionId,problemSlug:e.problem.slug,problemTitle:e.problem.title,difficulty:e.problem.difficulty,commitSha:r,githubPath:i,committedAt:Date.now(),lang:e.lang},u=await c.addCommit(a);if(t.autoReadme)try{const m=`${t.solutionSubfolder||"solutions"}/README.md`,l=this.generateReadmeContent(u,t);await this.putFile(t.githubToken,t.githubUsername,t.repoName,m,l,"leetie: Update solutions index README",t.branch)}catch(m){console.warn("[leetie] Auto README update failed:",m)}return a}}f(y,"BASE_URL","https://api.github.com");class g{static stopRecovery(){this.isRunning=!1}static async fetchSubmissionList(e,t=20){var a;const o=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionList($offset: Int!, $limit: Int!) {
        submissionList(offset: $offset, limit: $limit) {
          hasNext
          submissions {
            id
            statusDisplay
            lang
            timestamp
            titleSlug
          }
        }
      }
    `,variables:{offset:e,limit:t}})});if(!o.ok)throw new Error(`LeetCode API request failed: ${o.statusText}`);const s=await o.json(),r=(a=s==null?void 0:s.data)==null?void 0:a.submissionList;return{submissions:(r==null?void 0:r.submissions)||[],hasNext:!!(r!=null&&r.hasNext)}}static async fetchSubmissionDetail(e){var a;const i=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionDetails($id: Int!) {
        submissionDetails(submissionId: $id) {
          statusDisplay
          lang
          code
          runtime
          memory
          runtimePercentile
          memoryPercentile
          question {
            questionId
            title
            titleSlug
            difficulty
            topicTags {
              name
            }
          }
        }
      }
    `,variables:{id:Number(e)}})});if(!i.ok)return null;const o=await i.json(),s=(a=o==null?void 0:o.data)==null?void 0:a.submissionDetails;if(!s||s.statusDisplay!=="Accepted")return null;const r=s.question||{};return{submissionId:String(e),problem:{id:String(r.questionId||"0"),slug:r.titleSlug||"problem",title:r.title||"Problem",difficulty:r.difficulty||"Easy",topicTags:(r.topicTags||[]).map(u=>u.name||u)},lang:s.lang||"python3",code:s.code||"",runtime:s.runtime||"N/A",memory:s.memory||"N/A",runtimePercentile:Math.round(s.runtimePercentile||0),memoryPercentile:Math.round(s.memoryPercentile||0),timestamp:Date.now()}}static deduplicateSubmissions(e){const t=new Map;for(const i of e)if(i.statusDisplay==="Accepted"){const o=`${i.titleSlug}_${i.lang}`;t.has(o)||t.set(o,i)}return Array.from(t.values())}static async startRecovery(){if(!this.isRunning){this.isRunning=!0;try{await c.setState({syncStatus:"recovering",lastError:null});const e=[];let t=0;const i=20;for(;this.isRunning;){const r=await this.fetchSubmissionList(t,i);if(e.push(...r.submissions),await c.setState({recoveryProgress:{current:e.length,total:e.length+(r.hasNext?i:0)}}),!r.hasNext)break;t+=i,await new Promise(a=>setTimeout(a,300))}if(!this.isRunning){await c.setState({syncStatus:"idle",recoveryProgress:null});return}const o=this.deduplicateSubmissions(e),s=o.length;for(let r=0;r<s&&this.isRunning;r++){const a=o[r];await c.setState({recoveryProgress:{current:r+1,total:s}});try{const u=await this.fetchSubmissionDetail(a.id);u&&await y.commitSubmission(u)}catch(u){console.warn(`[leetie] Failed to commit item ${a.id}:`,u)}await new Promise(u=>setTimeout(u,400))}await c.setState({syncStatus:"idle",recoveryProgress:null})}catch(e){console.error("[leetie] History recovery error:",e),await c.setState({syncStatus:"error",lastError:e.message,recoveryProgress:null})}finally{this.isRunning=!1}}}}f(g,"LEETCODE_GRAPHQL","https://leetcode.com/graphql"),f(g,"isRunning",!1);console.log("[leetie] Background service worker initialized.");var S;typeof chrome<"u"&&((S=chrome.runtime)!=null&&S.onMessage)&&chrome.runtime.onMessage.addListener((n,e,t)=>{if(n.type==="GET_STATE")return c.getState().then(i=>t(i)),!0;if(n.type==="RECOVERY_START")return g.startRecovery(),t({success:!0,message:"History recovery started."}),!0;if(n.type==="RECOVERY_STOP")return g.stopRecovery(),t({success:!0,message:"History recovery stopped."}),!0;if(n.type==="TEST_CONNECTION"){const{token:i,repoName:o}=n.payload;return(async()=>{try{const s=await d.verifyUser(i),r=await d.ensureRepo(i,s.login,o);await c.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:s,repoOk:r})}catch(s){await c.setState({isAuthenticated:!1,lastError:s.message}),t({success:!1,error:s.message})}})(),!0}if(n.type==="START_OAUTH")return(async()=>{try{const i=await c.getConfig(),o=await P("Ov23liXXXXXXXXXX",i.proxyUrl),s=await d.verifyUser(o);await c.setConfig({githubToken:o,githubUsername:s.login}),await d.ensureRepo(o,s.login,i.repoName),await c.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:s})}catch(i){await c.setState({isAuthenticated:!1,lastError:i.message}),t({success:!1,error:i.message})}})(),!0;if(n.type==="FETCH_REPOS"){const{token:i}=n.payload;return d.getUserRepos(i).then(o=>t({success:!0,repos:o})).catch(o=>t({success:!1,error:o.message})),!0}if(n.type==="SUBMISSION_DETECTED"){const i=n.payload;return console.log("[leetie] Background worker orchestrating commit for:",i),(async()=>{try{await c.setState({syncStatus:"syncing"});const o=await y.commitSubmission(i);await c.setState({syncStatus:"idle",lastError:null}),typeof chrome<"u"&&chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"assets/icon-48.png",title:"leetie — Solution Synced!",message:`Successfully committed ${i.problem.id}. ${i.problem.title} [${i.problem.difficulty}] to GitHub.`}),t({success:!0,record:o})}catch(o){await c.setState({syncStatus:"error",lastError:o.message}),t({success:!1,error:o.message})}})(),!0}return!1});
