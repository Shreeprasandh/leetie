var P=Object.defineProperty;var A=(l,e,t)=>e in l?P(l,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):l[e]=t;var y=(l,e,t)=>A(l,typeof e!="symbol"?e+"":e,t);import{L as C,s as u,i as k}from"../assets/storage-CFDy9XGz.js";import{GitHubService as h}from"../assets/github.service-CoyREgGN.js";class b{static getHeaders(e){return{Authorization:`Bearer ${e}`,Accept:"application/vnd.github.v3+json","Content-Type":"application/json","User-Agent":"leetie-extension"}}static toBase64(e){return btoa(unescape(encodeURIComponent(e)))}static getExtension(e){const t=e.toLowerCase().trim();return C[t]||"txt"}static formatFilePath(e,t){const{problem:i,lang:o}=e,r=this.getExtension(o),s=String(i.id).padStart(4,"0"),a=t.solutionSubfolder||"solutions";return t.preferredDirFormat==="flat"?`${a}/${s}-${i.slug}/solution.${r}`:`${a}/${i.difficulty}/${s}-${i.slug}/solution.${r}`}static formatSolutionHeader(e){const{problem:t,lang:i,runtime:o,memory:r,runtimePercentile:s,memoryPercentile:a}=e,c=`https://leetcode.com/problems/${t.slug}/`,m=t.topicTags.length>0?t.topicTags.join(", "):"N/A",n=["html","xml"].includes(this.getExtension(i))?"<!--":"#",d=["html","xml"].includes(this.getExtension(i))?"-->":"";return`${n} ──────────────────────────────────────────────────
${n} Problem  : ${t.id}. ${t.title}
${n} Difficulty: ${t.difficulty}
${n} Tags     : ${m}
${n} Link     : ${c}
${n} Runtime  : ${o} (beats ${s}%)
${n} Memory   : ${r} (beats ${a}%)
${n} Language : ${i}
${n} Synced by: leetie
${n} ────────────────────────────────────────────────── ${d}

${e.code}`}static async getFileSha(e,t,i,o,r){try{const s=await fetch(`${this.BASE_URL}/repos/${t}/${i}/contents/${o}?ref=${r}`,{headers:this.getHeaders(e)});if(s.ok)return(await s.json()).sha||null}catch(s){console.warn(`[leetie] Error checking SHA for ${o}:`,s)}return null}static async putFile(e,t,i,o,r,s,a,c,m){var $,w;const n=await this.getFileSha(e,t,i,o,a),d={message:s,content:this.toBase64(r),branch:a};if(n&&(d.sha=n),c){const g=m||"leetie-user",E={name:g,email:`${g}@users.noreply.github.com`,date:c};d.author=E,d.committer=E}const f=await fetch(`${this.BASE_URL}/repos/${t}/${i}/contents/${o}`,{method:"PUT",headers:this.getHeaders(e),body:JSON.stringify(d)});if(!f.ok){const g=await f.json().catch(()=>({}));throw new Error(g.message||`GitHub Commit Failed (${f.status})`)}const S=await f.json();return(($=S.content)==null?void 0:$.sha)||((w=S.commit)==null?void 0:w.sha)||"success"}static generateReadmeContent(e,t){const i=t.solutionSubfolder||"solutions",o=e.map(r=>{const s=`https://leetcode.com/problems/${r.problemSlug}/`,a=`./${r.githubPath.replace(`${i}/`,"")}`;return`| ${r.problemSlug} | ${r.problemTitle} | ${r.difficulty} | ${r.lang} | [Problem](${s}) | [Solution](${a}) |`}).join(`
`);return`# My LeetCode Solutions

> *Automatically synced by [leetie](https://github.com/Shreeprasandh/leetie).*

## Progress Summary: ${e.length} Solved

| ID | Problem | Difficulty | Language | Problem Link | Solution Code |
|---|---------|-----------|----------|--------------|---------------|
${o}
`}static async commitSubmission(e){const t=await u.getConfig();if(!t.githubToken||!t.githubUsername)throw new Error("GitHub token or username not configured. Please open leetie options.");await h.ensureRepo(t.githubToken,t.githubUsername,t.repoName);const i=this.formatFilePath(e,t),o=t.addHeaderComment?this.formatSolutionHeader(e):e.code,r=`leetie: Add ${e.problem.id}. ${e.problem.title} [${e.problem.difficulty}] (${e.lang})`,s=e.timestamp?new Date(e.timestamp).toISOString():void 0,a=await this.putFile(t.githubToken,t.githubUsername,t.repoName,i,o,r,t.branch,s,t.githubUsername),c={submissionId:e.submissionId,problemSlug:e.problem.slug,problemTitle:e.problem.title,difficulty:e.problem.difficulty,commitSha:a,githubPath:i,committedAt:Date.now(),lang:e.lang},m=await u.addCommit(c);if(t.autoReadme)try{const n=`${t.solutionSubfolder||"solutions"}/README.md`,d=this.generateReadmeContent(m,t);await this.putFile(t.githubToken,t.githubUsername,t.repoName,n,d,"leetie: Update solutions index README",t.branch)}catch(n){console.warn("[leetie] Auto README update failed:",n)}return c}}y(b,"BASE_URL","https://api.github.com");class p{static stopRecovery(){this.isRunning=!1}static async fetchSubmissionList(e,t=20){var a;const o=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionList($offset: Int!, $limit: Int!) {
        submissionList(offset: $offset, limit: $limit) {
          hasNext
          submissions {
            id
            statusDisplay
            lang
            timestamp
            titleSlug
          }
        }
      }
    `,variables:{offset:e,limit:t}})});if(!o.ok)throw new Error(`LeetCode API request failed: ${o.statusText}`);const r=await o.json(),s=(a=r==null?void 0:r.data)==null?void 0:a.submissionList;return{submissions:(s==null?void 0:s.submissions)||[],hasNext:!!(s!=null&&s.hasNext)}}static async fetchSubmissionDetail(e,t){var m;const o=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionDetails($id: Int!) {
        submissionDetails(submissionId: $id) {
          statusDisplay
          lang
          code
          runtime
          memory
          runtimePercentile
          memoryPercentile
          timestamp
          question {
            questionId
            title
            titleSlug
            difficulty
            topicTags {
              name
            }
          }
        }
      }
    `,variables:{id:Number(e)}})});if(!o.ok)return null;const r=await o.json(),s=(m=r==null?void 0:r.data)==null?void 0:m.submissionDetails;if(!s||s.statusDisplay!=="Accepted")return null;const a=s.question||{},c=Number(s.timestamp||t||0);return{submissionId:String(e),problem:{id:String(a.questionId||"0"),slug:a.titleSlug||"problem",title:a.title||"Problem",difficulty:a.difficulty||"Easy",topicTags:(a.topicTags||[]).map(n=>n.name||n)},lang:s.lang||"python3",code:s.code||"",runtime:s.runtime||"N/A",memory:s.memory||"N/A",runtimePercentile:Math.round(s.runtimePercentile||0),memoryPercentile:Math.round(s.memoryPercentile||0),timestamp:c>0?c*1e3:Date.now()}}static deduplicateSubmissions(e){const t=new Map;for(const i of e)if(i.statusDisplay==="Accepted"){const o=`${i.titleSlug}_${i.lang}`;t.has(o)||t.set(o,i)}return Array.from(t.values())}static async startRecovery(){if(!this.isRunning){this.isRunning=!0;try{await u.setState({syncStatus:"recovering",lastError:null});const e=[];let t=0;const i=20;for(;this.isRunning;){const s=await this.fetchSubmissionList(t,i);if(e.push(...s.submissions),await u.setState({recoveryProgress:{current:e.length,total:e.length+(s.hasNext?i:0)}}),!s.hasNext)break;t+=i,await new Promise(a=>setTimeout(a,300))}if(!this.isRunning){await u.setState({syncStatus:"idle",recoveryProgress:null});return}const o=this.deduplicateSubmissions(e),r=o.length;for(let s=0;s<r&&this.isRunning;s++){const a=o[s];await u.setState({recoveryProgress:{current:s+1,total:r}});try{const c=await this.fetchSubmissionDetail(a.id,a.timestamp);c&&await b.commitSubmission(c)}catch(c){c.message&&c.message.includes("429")?(console.warn("[leetie] Rate limit encountered. Backing off for 5 seconds..."),await new Promise(m=>setTimeout(m,5e3))):console.warn(`[leetie] Failed to commit item ${a.id}:`,c)}await new Promise(c=>setTimeout(c,1e3))}await u.setState({syncStatus:"idle",recoveryProgress:null})}catch(e){console.error("[leetie] History recovery error:",e),await u.setState({syncStatus:"error",lastError:e.message,recoveryProgress:null})}finally{this.isRunning=!1}}}}y(p,"LEETCODE_GRAPHQL","https://leetcode.com/graphql"),y(p,"isRunning",!1);console.log("[leetie] Background service worker initialized.");var T;typeof chrome<"u"&&((T=chrome.runtime)!=null&&T.onMessage)&&chrome.runtime.onMessage.addListener((l,e,t)=>{if(l.type==="GET_STATE")return u.getState().then(i=>t(i)),!0;if(l.type==="RECOVERY_START")return p.startRecovery(),t({success:!0,message:"History recovery started."}),!0;if(l.type==="RECOVERY_STOP")return p.stopRecovery(),t({success:!0,message:"History recovery stopped."}),!0;if(l.type==="TEST_CONNECTION"){const{token:i,repoName:o}=l.payload;return(async()=>{try{const r=await h.verifyUser(i),s=await h.ensureRepo(i,r.login,o);await u.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:r,repoOk:s})}catch(r){await u.setState({isAuthenticated:!1,lastError:r.message}),t({success:!1,error:r.message})}})(),!0}if(l.type==="START_OAUTH")return(async()=>{try{const i=await u.getConfig(),o=await k("Ov23li296L9RxwhuLXOv",i.proxyUrl),r=await h.verifyUser(o);await u.setConfig({githubToken:o,githubUsername:r.login}),await h.ensureRepo(o,r.login,i.repoName),await u.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:r})}catch(i){await u.setState({isAuthenticated:!1,lastError:i.message}),t({success:!1,error:i.message})}})(),!0;if(l.type==="FETCH_REPOS"){const{token:i}=l.payload;return h.getUserRepos(i).then(o=>t({success:!0,repos:o})).catch(o=>t({success:!1,error:o.message})),!0}if(l.type==="SUBMISSION_DETECTED"){const i=l.payload;return console.log("[leetie] Background worker orchestrating commit for:",i),(async()=>{try{await u.setState({syncStatus:"syncing"});const o=await b.commitSubmission(i);await u.setState({syncStatus:"idle",lastError:null}),typeof chrome<"u"&&chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"assets/icon-48.png",title:"leetie — Solution Synced!",message:`Successfully committed ${i.problem.id}. ${i.problem.title} [${i.problem.difficulty}] to GitHub.`}),t({success:!0,record:o})}catch(o){await u.setState({syncStatus:"error",lastError:o.message}),t({success:!1,error:o.message})}})(),!0}return!1});
