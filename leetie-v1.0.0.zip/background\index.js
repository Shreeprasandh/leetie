var w=Object.defineProperty;var E=(n,e,t)=>e in n?w(n,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):n[e]=t;var f=(n,e,t)=>E(n,typeof e!="symbol"?e+"":e,t);import{L as T,s as l,i as P}from"../assets/storage-CFDy9XGz.js";import{GitHubService as d}from"../assets/github.service-CoyREgGN.js";class y{static getHeaders(e){return{Authorization:`Bearer ${e}`,Accept:"application/vnd.github.v3+json","Content-Type":"application/json","User-Agent":"leetie-extension"}}static toBase64(e){return btoa(unescape(encodeURIComponent(e)))}static getExtension(e){const t=e.toLowerCase().trim();return T[t]||"txt"}static formatFilePath(e,t){const{problem:s,lang:o}=e,i=this.getExtension(o),r=String(s.id).padStart(4,"0"),a=t.solutionSubfolder||"solutions";return t.preferredDirFormat==="flat"?`${a}/${r}-${s.slug}/solution.${i}`:`${a}/${s.difficulty}/${r}-${s.slug}/solution.${i}`}static formatSolutionHeader(e){const{problem:t,lang:s,runtime:o,memory:i,runtimePercentile:r,memoryPercentile:a}=e,c=`https://leetcode.com/problems/${t.slug}/`,m=t.topicTags.length>0?t.topicTags.join(", "):"N/A",u=["html","xml"].includes(this.getExtension(s))?"<!--":"#",h=["html","xml"].includes(this.getExtension(s))?"-->":"";return`${u} ──────────────────────────────────────────────────
${u} Problem  : ${t.id}. ${t.title}
${u} Difficulty: ${t.difficulty}
${u} Tags     : ${m}
${u} Link     : ${c}
${u} Runtime  : ${o} (beats ${r}%)
${u} Memory   : ${i} (beats ${a}%)
${u} Language : ${s}
${u} Synced by: leetie
${u} ────────────────────────────────────────────────── ${h}

${e.code}`}static async getFileSha(e,t,s,o,i){try{const r=await fetch(`${this.BASE_URL}/repos/${t}/${s}/contents/${o}?ref=${i}`,{headers:this.getHeaders(e)});if(r.ok)return(await r.json()).sha||null}catch(r){console.warn(`[leetie] Error checking SHA for ${o}:`,r)}return null}static async putFile(e,t,s,o,i,r,a){var p,b;const c=await this.getFileSha(e,t,s,o,a),m={message:r,content:this.toBase64(i),branch:a};c&&(m.sha=c);const u=await fetch(`${this.BASE_URL}/repos/${t}/${s}/contents/${o}`,{method:"PUT",headers:this.getHeaders(e),body:JSON.stringify(m)});if(!u.ok){const $=await u.json().catch(()=>({}));throw new Error($.message||`GitHub Commit Failed (${u.status})`)}const h=await u.json();return((p=h.content)==null?void 0:p.sha)||((b=h.commit)==null?void 0:b.sha)||"success"}static generateReadmeContent(e,t){const s=t.solutionSubfolder||"solutions",o=e.map(i=>{const r=`https://leetcode.com/problems/${i.problemSlug}/`,a=`./${i.githubPath.replace(`${s}/`,"")}`;return`| ${i.problemSlug} | ${i.problemTitle} | ${i.difficulty} | ${i.lang} | [Problem](${r}) | [Solution](${a}) |`}).join(`
`);return`# My LeetCode Solutions

> *Automatically synced by [leetie](https://github.com/Shreeprasandh/leetie).*

## Progress Summary: ${e.length} Solved

| ID | Problem | Difficulty | Language | Problem Link | Solution Code |
|---|---------|-----------|----------|--------------|---------------|
${o}
`}static async commitSubmission(e){const t=await l.getConfig();if(!t.githubToken||!t.githubUsername)throw new Error("GitHub token or username not configured. Please open leetie options.");await d.ensureRepo(t.githubToken,t.githubUsername,t.repoName);const s=this.formatFilePath(e,t),o=t.addHeaderComment?this.formatSolutionHeader(e):e.code,i=`leetie: Add ${e.problem.id}. ${e.problem.title} [${e.problem.difficulty}] (${e.lang})`,r=await this.putFile(t.githubToken,t.githubUsername,t.repoName,s,o,i,t.branch),a={submissionId:e.submissionId,problemSlug:e.problem.slug,problemTitle:e.problem.title,difficulty:e.problem.difficulty,commitSha:r,githubPath:s,committedAt:Date.now(),lang:e.lang},c=await l.addCommit(a);if(t.autoReadme)try{const m=`${t.solutionSubfolder||"solutions"}/README.md`,u=this.generateReadmeContent(c,t);await this.putFile(t.githubToken,t.githubUsername,t.repoName,m,u,"leetie: Update solutions index README",t.branch)}catch(m){console.warn("[leetie] Auto README update failed:",m)}return a}}f(y,"BASE_URL","https://api.github.com");class g{static stopRecovery(){this.isRunning=!1}static async fetchSubmissionList(e,t=20){var a;const o=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionList($offset: Int!, $limit: Int!) {
        submissionList(offset: $offset, limit: $limit) {
          hasNext
          submissions {
            id
            statusDisplay
            lang
            timestamp
            titleSlug
          }
        }
      }
    `,variables:{offset:e,limit:t}})});if(!o.ok)throw new Error(`LeetCode API request failed: ${o.statusText}`);const i=await o.json(),r=(a=i==null?void 0:i.data)==null?void 0:a.submissionList;return{submissions:(r==null?void 0:r.submissions)||[],hasNext:!!(r!=null&&r.hasNext)}}static async fetchSubmissionDetail(e){var a;const s=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionDetails($id: Int!) {
        submissionDetails(submissionId: $id) {
          statusDisplay
          lang
          code
          runtime
          memory
          runtimePercentile
          memoryPercentile
          question {
            questionId
            title
            titleSlug
            difficulty
            topicTags {
              name
            }
          }
        }
      }
    `,variables:{id:Number(e)}})});if(!s.ok)return null;const o=await s.json(),i=(a=o==null?void 0:o.data)==null?void 0:a.submissionDetails;if(!i||i.statusDisplay!=="Accepted")return null;const r=i.question||{};return{submissionId:String(e),problem:{id:String(r.questionId||"0"),slug:r.titleSlug||"problem",title:r.title||"Problem",difficulty:r.difficulty||"Easy",topicTags:(r.topicTags||[]).map(c=>c.name||c)},lang:i.lang||"python3",code:i.code||"",runtime:i.runtime||"N/A",memory:i.memory||"N/A",runtimePercentile:Math.round(i.runtimePercentile||0),memoryPercentile:Math.round(i.memoryPercentile||0),timestamp:Date.now()}}static deduplicateSubmissions(e){const t=new Map;for(const s of e)if(s.statusDisplay==="Accepted"){const o=`${s.titleSlug}_${s.lang}`;t.has(o)||t.set(o,s)}return Array.from(t.values())}static async startRecovery(){if(!this.isRunning){this.isRunning=!0;try{await l.setState({syncStatus:"recovering",lastError:null});const e=[];let t=0;const s=20;for(;this.isRunning;){const r=await this.fetchSubmissionList(t,s);if(e.push(...r.submissions),await l.setState({recoveryProgress:{current:e.length,total:e.length+(r.hasNext?s:0)}}),!r.hasNext)break;t+=s,await new Promise(a=>setTimeout(a,300))}if(!this.isRunning){await l.setState({syncStatus:"idle",recoveryProgress:null});return}const o=this.deduplicateSubmissions(e),i=o.length;for(let r=0;r<i&&this.isRunning;r++){const a=o[r];await l.setState({recoveryProgress:{current:r+1,total:i}});try{const c=await this.fetchSubmissionDetail(a.id);c&&await y.commitSubmission(c)}catch(c){c.message&&c.message.includes("429")?(console.warn("[leetie] Rate limit encountered. Backing off for 5 seconds..."),await new Promise(m=>setTimeout(m,5e3))):console.warn(`[leetie] Failed to commit item ${a.id}:`,c)}await new Promise(c=>setTimeout(c,1e3))}await l.setState({syncStatus:"idle",recoveryProgress:null})}catch(e){console.error("[leetie] History recovery error:",e),await l.setState({syncStatus:"error",lastError:e.message,recoveryProgress:null})}finally{this.isRunning=!1}}}}f(g,"LEETCODE_GRAPHQL","https://leetcode.com/graphql"),f(g,"isRunning",!1);console.log("[leetie] Background service worker initialized.");var S;typeof chrome<"u"&&((S=chrome.runtime)!=null&&S.onMessage)&&chrome.runtime.onMessage.addListener((n,e,t)=>{if(n.type==="GET_STATE")return l.getState().then(s=>t(s)),!0;if(n.type==="RECOVERY_START")return g.startRecovery(),t({success:!0,message:"History recovery started."}),!0;if(n.type==="RECOVERY_STOP")return g.stopRecovery(),t({success:!0,message:"History recovery stopped."}),!0;if(n.type==="TEST_CONNECTION"){const{token:s,repoName:o}=n.payload;return(async()=>{try{const i=await d.verifyUser(s),r=await d.ensureRepo(s,i.login,o);await l.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:i,repoOk:r})}catch(i){await l.setState({isAuthenticated:!1,lastError:i.message}),t({success:!1,error:i.message})}})(),!0}if(n.type==="START_OAUTH")return(async()=>{try{const s=await l.getConfig(),o=await P("Ov23li296L9RxwhuLXOv",s.proxyUrl),i=await d.verifyUser(o);await l.setConfig({githubToken:o,githubUsername:i.login}),await d.ensureRepo(o,i.login,s.repoName),await l.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:i})}catch(s){await l.setState({isAuthenticated:!1,lastError:s.message}),t({success:!1,error:s.message})}})(),!0;if(n.type==="FETCH_REPOS"){const{token:s}=n.payload;return d.getUserRepos(s).then(o=>t({success:!0,repos:o})).catch(o=>t({success:!1,error:o.message})),!0}if(n.type==="SUBMISSION_DETECTED"){const s=n.payload;return console.log("[leetie] Background worker orchestrating commit for:",s),(async()=>{try{await l.setState({syncStatus:"syncing"});const o=await y.commitSubmission(s);await l.setState({syncStatus:"idle",lastError:null}),typeof chrome<"u"&&chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"assets/icon-48.png",title:"leetie — Solution Synced!",message:`Successfully committed ${s.problem.id}. ${s.problem.title} [${s.problem.difficulty}] to GitHub.`}),t({success:!0,record:o})}catch(o){await l.setState({syncStatus:"error",lastError:o.message}),t({success:!1,error:o.message})}})(),!0}return!1});
