var A=Object.defineProperty;var k=(u,e,t)=>e in u?A(u,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):u[e]=t;var y=(u,e,t)=>k(u,typeof e!="symbol"?e+"":e,t);import{L as C,s as l,i as R}from"../assets/storage-DflHnpjp.js";import{GitHubService as f}from"../assets/github.service-CoyREgGN.js";class S{static getHeaders(e){return{Authorization:`Bearer ${e}`,Accept:"application/vnd.github.v3+json","Content-Type":"application/json","User-Agent":"leetie-extension"}}static toBase64(e){return btoa(unescape(encodeURIComponent(e||"")))}static getExtension(e){const t=e.toLowerCase().trim();return C[t]||"txt"}static formatFilePath(e,t){const{problem:s,lang:i}=e,r=this.getExtension(i),n=String(s.id).padStart(4,"0"),a=t.solutionSubfolder||"solutions";return t.preferredDirFormat==="flat"?`${a}/${n}-${s.slug}/solution.${r}`:`${a}/${s.difficulty}/${n}-${s.slug}/solution.${r}`}static formatSolutionHeader(e){const{problem:t,lang:s,runtime:i,memory:r,runtimePercentile:n,memoryPercentile:a}=e,c=`https://leetcode.com/problems/${t.slug}/`,m=t.topicTags.length>0?t.topicTags.join(", "):"N/A",o=["html","xml"].includes(this.getExtension(s))?"<!--":"#",g=["html","xml"].includes(this.getExtension(s))?"-->":"";return`${o} ──────────────────────────────────────────────────
${o} Problem  : ${t.id}. ${t.title}
${o} Difficulty: ${t.difficulty}
${o} Tags     : ${m}
${o} Link     : ${c}
${o} Runtime  : ${i} (beats ${n}%)
${o} Memory   : ${r} (beats ${a}%)
${o} Language : ${s}
${o} Synced by: leetie
${o} ────────────────────────────────────────────────── ${g}

${e.code}`}static async getFileSha(e,t,s,i,r){try{const n=await fetch(`${this.BASE_URL}/repos/${t}/${s}/contents/${i}?ref=${r}`,{headers:this.getHeaders(e)});if(n.ok)return(await n.json()).sha||null}catch(n){console.warn(`[leetie] Error checking SHA for ${i}:`,n)}return null}static async putFile(e,t,s,i,r,n,a,c,m){var w,E;const o=await this.getFileSha(e,t,s,i,a),g={message:n,content:this.toBase64(r),branch:a};if(o&&(g.sha=o),c){const h=m||"leetie-user",b=`${h.toLowerCase()}@users.noreply.github.com`,T={name:h,email:b,date:c};g.author=T,g.committer=T}const d=await fetch(`${this.BASE_URL}/repos/${t}/${s}/contents/${i}`,{method:"PUT",headers:this.getHeaders(e),body:JSON.stringify(g)});if(!d.ok){const h=await d.json().catch(()=>({})),b=h.message||h.error||`HTTP ${d.status}`;throw console.error(`[leetie] GitHub API PUT error (${d.status}) on ${i}:`,h),new Error(`GitHub API Error (${d.status}): ${b}`)}const $=await d.json();return((w=$.content)==null?void 0:w.sha)||((E=$.commit)==null?void 0:E.sha)||"success"}static generateReadmeContent(e,t){const s=t.solutionSubfolder||"solutions",i=e.map(r=>{const n=`https://leetcode.com/problems/${r.problemSlug}/`,a=`./${r.githubPath.replace(`${s}/`,"")}`,c=r.problemTitle.replace(/\|/g,"\\|");return`| ${r.problemSlug} | ${c} | ${r.difficulty} | ${r.lang} | [Problem](${n}) | [Solution](${a}) |`}).join(`
`);return`# My LeetCode Solutions

> *Automatically synced by [leetie](https://github.com/Shreeprasandh/leetie).*

## Progress Summary: ${e.length} Solved

| ID | Problem | Difficulty | Language | Problem Link | Solution Code |
|---|---------|-----------|----------|--------------|---------------|
${i}
`}static async commitSubmission(e){const t=await l.getConfig();if(!t.githubToken||!t.githubUsername)throw new Error("GitHub token or username not configured. Please open leetie options.");await f.ensureRepo(t.githubToken,t.githubUsername,t.repoName);const s=this.formatFilePath(e,t),i=t.addHeaderComment?this.formatSolutionHeader(e):e.code,r=`leetie: Add ${e.problem.id}. ${e.problem.title} [${e.problem.difficulty}] (${e.lang})`;let n;if(e.timestamp){const o=Number(e.timestamp),g=o<1e10?o*1e3:o,d=new Date(g);isNaN(d.getTime())||(n=d.toISOString())}const a=await this.putFile(t.githubToken,t.githubUsername,t.repoName,s,i,r,t.branch,n,t.githubUsername),c={submissionId:e.submissionId,problemSlug:e.problem.slug,problemTitle:e.problem.title,difficulty:e.problem.difficulty,commitSha:a,githubPath:s,committedAt:Date.now(),lang:e.lang},m=await l.addCommit(c);if(t.autoReadme)try{const o=`${t.solutionSubfolder||"solutions"}/README.md`,g=this.generateReadmeContent(m,t);await this.putFile(t.githubToken,t.githubUsername,t.repoName,o,g,"leetie: Update solutions index README",t.branch)}catch(o){console.warn("[leetie] Auto README update failed:",o)}return c}}y(S,"BASE_URL","https://api.github.com");class p{static stopRecovery(){this.isRunning=!1}static async getHeaders(){const e={"Content-Type":"application/json",Referer:"https://leetcode.com",Origin:"https://leetcode.com"};if(typeof chrome<"u"&&chrome.cookies)try{const t=await chrome.cookies.get({url:"https://leetcode.com",name:"csrftoken"});t!=null&&t.value&&(e["x-csrftoken"]=t.value)}catch{}return e}static async fetchSubmissionList(e,t=20){var c;const s=`
      query submissionList($offset: Int!, $limit: Int!) {
        submissionList(offset: $offset, limit: $limit) {
          hasNext
          submissions {
            id
            statusDisplay
            lang
            timestamp
            titleSlug
          }
        }
      }
    `,i=await this.getHeaders(),r=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:i,credentials:"include",body:JSON.stringify({operationName:"submissionList",query:s,variables:{offset:e,limit:t}})});if(!r.ok)throw new Error(`LeetCode API request failed: ${r.statusText}`);const n=await r.json(),a=(c=n==null?void 0:n.data)==null?void 0:c.submissionList;return{submissions:(a==null?void 0:a.submissions)||[],hasNext:!!(a!=null&&a.hasNext)}}static async fetchSubmissionDetail(e,t){var o;const s=`
      query submissionDetails($submissionId: Int!) {
        submissionDetails(submissionId: $submissionId) {
          statusDisplay
          lang
          code
          runtime
          memory
          runtimePercentile
          memoryPercentile
          timestamp
          question {
            questionId
            title
            titleSlug
            difficulty
            topicTags {
              name
            }
          }
        }
      }
    `,i=await this.getHeaders(),r=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:i,credentials:"include",body:JSON.stringify({operationName:"submissionDetails",query:s,variables:{submissionId:Number(e)}})});if(!r.ok)return console.warn(`[leetie] fetchSubmissionDetail HTTP error ${r.status} for id ${e}`),null;const n=await r.json(),a=(o=n==null?void 0:n.data)==null?void 0:o.submissionDetails;if(!a)return console.warn(`[leetie] fetchSubmissionDetail returned null details for id ${e}:`,n),null;if(a.statusDisplay!=="Accepted")return null;const c=a.question||{},m=Number(a.timestamp||t||0);return{submissionId:String(e),problem:{id:String(c.questionId||"0"),slug:c.titleSlug||"problem",title:c.title||"Problem",difficulty:c.difficulty||"Easy",topicTags:(c.topicTags||[]).map(g=>g.name||g)},lang:a.lang||"python3",code:a.code||"",runtime:a.runtime||"N/A",memory:a.memory||"N/A",runtimePercentile:Math.round(a.runtimePercentile||0),memoryPercentile:Math.round(a.memoryPercentile||0),timestamp:m>0?m*1e3:Date.now()}}static deduplicateSubmissions(e){const t=new Map;for(const s of e)if(s.statusDisplay==="Accepted"){const i=`${s.titleSlug}_${s.lang}`;t.has(i)||t.set(i,s)}return Array.from(t.values())}static async startRecovery(){if(!this.isRunning){this.isRunning=!0;try{const e=await l.getConfig();if(!e.githubToken||!e.githubUsername){await l.setState({syncStatus:"error",lastError:"GitHub Token or Username is missing. Please connect your GitHub account first.",recoveryProgress:null}),this.isRunning=!1;return}await l.setState({syncStatus:"recovering",lastError:null});const t=[];let s=0;const i=20;for(;this.isRunning;){const c=await this.fetchSubmissionList(s,i);if(t.push(...c.submissions),await l.setState({recoveryProgress:{current:t.length,total:t.length+(c.hasNext?i:0)}}),!c.hasNext)break;s+=i,await new Promise(m=>setTimeout(m,300))}if(!this.isRunning){await l.setState({syncStatus:"idle",recoveryProgress:null});return}const r=this.deduplicateSubmissions(t),n=r.length;let a=0;for(let c=0;c<n&&this.isRunning;c++){const m=r[c];await l.setState({recoveryProgress:{current:c+1,total:n}});try{const o=await this.fetchSubmissionDetail(m.id,m.timestamp);o&&(await S.commitSubmission(o),a++)}catch(o){console.warn(`[leetie] Failed to commit item ${m.id}:`,o),o.message&&o.message.includes("429")?(console.warn("[leetie] Rate limit encountered. Backing off for 5 seconds..."),await new Promise(g=>setTimeout(g,5e3))):await l.setState({lastError:`Commit error on #${m.titleSlug}: ${o.message}`})}await new Promise(o=>setTimeout(o,1e3))}await l.setState({syncStatus:"idle",recoveryProgress:null,lastError:a===0&&n>0?"Recovery completed but 0 commits succeeded. Please check GitHub permissions.":null})}catch(e){console.error("[leetie] History recovery error:",e),await l.setState({syncStatus:"error",lastError:e.message,recoveryProgress:null})}finally{this.isRunning=!1}}}}y(p,"LEETCODE_GRAPHQL","https://leetcode.com/graphql"),y(p,"isRunning",!1);console.log("[leetie] Background service worker initialized.");var P;typeof chrome<"u"&&((P=chrome.runtime)!=null&&P.onMessage)&&chrome.runtime.onMessage.addListener((u,e,t)=>{if(u.type==="GET_STATE")return l.getState().then(s=>t(s)),!0;if(u.type==="RECOVERY_START")return p.startRecovery(),t({success:!0,message:"History recovery started."}),!0;if(u.type==="RECOVERY_STOP")return p.stopRecovery(),t({success:!0,message:"History recovery stopped."}),!0;if(u.type==="TEST_CONNECTION"){const{token:s,repoName:i}=u.payload;return(async()=>{try{const r=await f.verifyUser(s);await l.setConfig({githubToken:s,githubUsername:r.login});const n=await f.ensureRepo(s,r.login,i);await l.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:r,repoOk:n})}catch(r){await l.setState({isAuthenticated:!1,lastError:r.message}),t({success:!1,error:r.message})}})(),!0}if(u.type==="START_OAUTH")return(async()=>{try{const s=await l.getConfig(),i=await R("Ov23li296L9RxwhuLXOv",s.proxyUrl),r=await f.verifyUser(i);await l.setConfig({githubToken:i,githubUsername:r.login}),await f.ensureRepo(i,r.login,s.repoName),await l.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:r})}catch(s){await l.setState({isAuthenticated:!1,lastError:s.message}),t({success:!1,error:s.message})}})(),!0;if(u.type==="FETCH_REPOS"){const{token:s}=u.payload;return f.getUserRepos(s).then(i=>t({success:!0,repos:i})).catch(i=>t({success:!1,error:i.message})),!0}if(u.type==="SUBMISSION_DETECTED"){const s=u.payload;return console.log("[leetie] Background worker orchestrating commit for:",s),(async()=>{try{await l.setState({syncStatus:"syncing"});const i=await S.commitSubmission(s);await l.setState({syncStatus:"idle",lastError:null}),typeof chrome<"u"&&chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"assets/icon-48.png",title:"leetie — Solution Synced!",message:`Successfully committed ${s.problem.id}. ${s.problem.title} [${s.problem.difficulty}] to GitHub.`}),t({success:!0,record:i})}catch(i){await l.setState({syncStatus:"error",lastError:i.message}),t({success:!1,error:i.message})}})(),!0}return!1});
