var w=Object.defineProperty;var E=(a,e,t)=>e in a?w(a,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):a[e]=t;var h=(a,e,t)=>E(a,typeof e!="symbol"?e+"":e,t);import{L as P,s as u}from"../assets/storage-CwjZty_n.js";import{GitHubService as f}from"../assets/github.service-CoyREgGN.js";class y{static getHeaders(e){return{Authorization:`Bearer ${e}`,Accept:"application/vnd.github.v3+json","Content-Type":"application/json","User-Agent":"leetie-extension"}}static toBase64(e){return btoa(unescape(encodeURIComponent(e)))}static getExtension(e){const t=e.toLowerCase().trim();return P[t]||"txt"}static formatFilePath(e,t){const{problem:s,lang:r}=e,i=this.getExtension(r),o=String(s.id).padStart(4,"0"),n=t.solutionSubfolder||"solutions";return t.preferredDirFormat==="flat"?`${n}/${o}-${s.slug}/solution.${i}`:`${n}/${s.difficulty}/${o}-${s.slug}/solution.${i}`}static formatSolutionHeader(e){const{problem:t,lang:s,runtime:r,memory:i,runtimePercentile:o,memoryPercentile:n}=e,l=`https://leetcode.com/problems/${t.slug}/`,m=t.topicTags.length>0?t.topicTags.join(", "):"N/A",c=["html","xml"].includes(this.getExtension(s))?"<!--":"#",d=["html","xml"].includes(this.getExtension(s))?"-->":"";return`${c} ──────────────────────────────────────────────────
${c} Problem  : ${t.id}. ${t.title}
${c} Difficulty: ${t.difficulty}
${c} Tags     : ${m}
${c} Link     : ${l}
${c} Runtime  : ${r} (beats ${o}%)
${c} Memory   : ${i} (beats ${n}%)
${c} Language : ${s}
${c} Synced by: leetie
${c} ────────────────────────────────────────────────── ${d}

${e.code}`}static async getFileSha(e,t,s,r,i){try{const o=await fetch(`${this.BASE_URL}/repos/${t}/${s}/contents/${r}?ref=${i}`,{headers:this.getHeaders(e)});if(o.ok)return(await o.json()).sha||null}catch(o){console.warn(`[leetie] Error checking SHA for ${r}:`,o)}return null}static async putFile(e,t,s,r,i,o,n){var p,b;const l=await this.getFileSha(e,t,s,r,n),m={message:o,content:this.toBase64(i),branch:n};l&&(m.sha=l);const c=await fetch(`${this.BASE_URL}/repos/${t}/${s}/contents/${r}`,{method:"PUT",headers:this.getHeaders(e),body:JSON.stringify(m)});if(!c.ok){const $=await c.json().catch(()=>({}));throw new Error($.message||`GitHub Commit Failed (${c.status})`)}const d=await c.json();return((p=d.content)==null?void 0:p.sha)||((b=d.commit)==null?void 0:b.sha)||"success"}static generateReadmeContent(e,t){const s=t.solutionSubfolder||"solutions",r=e.map(i=>{const o=`https://leetcode.com/problems/${i.problemSlug}/`,n=`./${i.githubPath.replace(`${s}/`,"")}`;return`| ${i.problemSlug} | ${i.problemTitle} | ${i.difficulty} | ${i.lang} | [Problem](${o}) | [Solution](${n}) |`}).join(`
`);return`# My LeetCode Solutions

> *Automatically synced by [leetie](https://github.com/Shreeprasandh/leetie).*

## Progress Summary: ${e.length} Solved

| ID | Problem | Difficulty | Language | Problem Link | Solution Code |
|---|---------|-----------|----------|--------------|---------------|
${r}
`}static async commitSubmission(e){const t=await u.getConfig();if(!t.githubToken||!t.githubUsername)throw new Error("GitHub token or username not configured. Please open leetie options.");await f.ensureRepo(t.githubToken,t.githubUsername,t.repoName);const s=this.formatFilePath(e,t),r=t.addHeaderComment?this.formatSolutionHeader(e):e.code,i=`leetie: Add ${e.problem.id}. ${e.problem.title} [${e.problem.difficulty}] (${e.lang})`,o=await this.putFile(t.githubToken,t.githubUsername,t.repoName,s,r,i,t.branch),n={submissionId:e.submissionId,problemSlug:e.problem.slug,problemTitle:e.problem.title,difficulty:e.problem.difficulty,commitSha:o,githubPath:s,committedAt:Date.now(),lang:e.lang},l=await u.addCommit(n);if(t.autoReadme)try{const m=`${t.solutionSubfolder||"solutions"}/README.md`,c=this.generateReadmeContent(l,t);await this.putFile(t.githubToken,t.githubUsername,t.repoName,m,c,"leetie: Update solutions index README",t.branch)}catch(m){console.warn("[leetie] Auto README update failed:",m)}return n}}h(y,"BASE_URL","https://api.github.com");class g{static stopRecovery(){this.isRunning=!1}static async fetchSubmissionList(e,t=20){var n;const r=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionList($offset: Int!, $limit: Int!) {
        submissionList(offset: $offset, limit: $limit) {
          hasNext
          submissions {
            id
            statusDisplay
            lang
            timestamp
            titleSlug
          }
        }
      }
    `,variables:{offset:e,limit:t}})});if(!r.ok)throw new Error(`LeetCode API request failed: ${r.statusText}`);const i=await r.json(),o=(n=i==null?void 0:i.data)==null?void 0:n.submissionList;return{submissions:(o==null?void 0:o.submissions)||[],hasNext:!!(o!=null&&o.hasNext)}}static async fetchSubmissionDetail(e){var n;const s=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionDetails($id: Int!) {
        submissionDetails(submissionId: $id) {
          statusDisplay
          lang
          code
          runtime
          memory
          runtimePercentile
          memoryPercentile
          question {
            questionId
            title
            titleSlug
            difficulty
            topicTags {
              name
            }
          }
        }
      }
    `,variables:{id:Number(e)}})});if(!s.ok)return null;const r=await s.json(),i=(n=r==null?void 0:r.data)==null?void 0:n.submissionDetails;if(!i||i.statusDisplay!=="Accepted")return null;const o=i.question||{};return{submissionId:String(e),problem:{id:String(o.questionId||"0"),slug:o.titleSlug||"problem",title:o.title||"Problem",difficulty:o.difficulty||"Easy",topicTags:(o.topicTags||[]).map(l=>l.name||l)},lang:i.lang||"python3",code:i.code||"",runtime:i.runtime||"N/A",memory:i.memory||"N/A",runtimePercentile:Math.round(i.runtimePercentile||0),memoryPercentile:Math.round(i.memoryPercentile||0),timestamp:Date.now()}}static deduplicateSubmissions(e){const t=new Map;for(const s of e)if(s.statusDisplay==="Accepted"){const r=`${s.titleSlug}_${s.lang}`;t.has(r)||t.set(r,s)}return Array.from(t.values())}static async startRecovery(){if(!this.isRunning){this.isRunning=!0;try{await u.setState({syncStatus:"recovering",lastError:null});const e=[];let t=0;const s=20;for(;this.isRunning;){const o=await this.fetchSubmissionList(t,s);if(e.push(...o.submissions),await u.setState({recoveryProgress:{current:e.length,total:e.length+(o.hasNext?s:0)}}),!o.hasNext)break;t+=s,await new Promise(n=>setTimeout(n,300))}if(!this.isRunning){await u.setState({syncStatus:"idle",recoveryProgress:null});return}const r=this.deduplicateSubmissions(e),i=r.length;for(let o=0;o<i&&this.isRunning;o++){const n=r[o];await u.setState({recoveryProgress:{current:o+1,total:i}});try{const l=await this.fetchSubmissionDetail(n.id);l&&await y.commitSubmission(l)}catch(l){console.warn(`[leetie] Failed to commit item ${n.id}:`,l)}await new Promise(l=>setTimeout(l,400))}await u.setState({syncStatus:"idle",recoveryProgress:null})}catch(e){console.error("[leetie] History recovery error:",e),await u.setState({syncStatus:"error",lastError:e.message,recoveryProgress:null})}finally{this.isRunning=!1}}}}h(g,"LEETCODE_GRAPHQL","https://leetcode.com/graphql"),h(g,"isRunning",!1);console.log("[leetie] Background service worker initialized.");var S;typeof chrome<"u"&&((S=chrome.runtime)!=null&&S.onMessage)&&chrome.runtime.onMessage.addListener((a,e,t)=>{if(a.type==="GET_STATE")return u.getState().then(s=>t(s)),!0;if(a.type==="RECOVERY_START")return g.startRecovery(),t({success:!0,message:"History recovery started."}),!0;if(a.type==="RECOVERY_STOP")return g.stopRecovery(),t({success:!0,message:"History recovery stopped."}),!0;if(a.type==="TEST_CONNECTION"){const{token:s,repoName:r}=a.payload;return(async()=>{try{const i=await f.verifyUser(s),o=await f.ensureRepo(s,i.login,r);await u.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:i,repoOk:o})}catch(i){await u.setState({isAuthenticated:!1,lastError:i.message}),t({success:!1,error:i.message})}})(),!0}if(a.type==="FETCH_REPOS"){const{token:s}=a.payload;return f.getUserRepos(s).then(r=>t({success:!0,repos:r})).catch(r=>t({success:!1,error:r.message})),!0}if(a.type==="SUBMISSION_DETECTED"){const s=a.payload;return console.log("[leetie] Background worker orchestrating commit for:",s),(async()=>{try{await u.setState({syncStatus:"syncing"});const r=await y.commitSubmission(s);await u.setState({syncStatus:"idle",lastError:null}),typeof chrome<"u"&&chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"assets/icon-48.png",title:"leetie — Solution Synced!",message:`Successfully committed ${s.problem.id}. ${s.problem.title} [${s.problem.difficulty}] to GitHub.`}),t({success:!0,record:r})}catch(r){await u.setState({syncStatus:"error",lastError:r.message}),t({success:!1,error:r.message})}})(),!0}return!1});
