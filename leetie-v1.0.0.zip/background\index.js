var A=Object.defineProperty;var C=(u,e,t)=>e in u?A(u,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):u[e]=t;var y=(u,e,t)=>C(u,typeof e!="symbol"?e+"":e,t);import{L as k,s as l,i as R}from"../assets/storage-FzEOA2WQ.js";import{GitHubService as f}from"../assets/github.service-CoyREgGN.js";class S{static getHeaders(e){return{Authorization:`Bearer ${e}`,Accept:"application/vnd.github.v3+json","Content-Type":"application/json","User-Agent":"leetie-extension"}}static toBase64(e){return btoa(unescape(encodeURIComponent(e)))}static getExtension(e){const t=e.toLowerCase().trim();return k[t]||"txt"}static formatFilePath(e,t){const{problem:s,lang:i}=e,r=this.getExtension(i),o=String(s.id).padStart(4,"0"),n=t.solutionSubfolder||"solutions";return t.preferredDirFormat==="flat"?`${n}/${o}-${s.slug}/solution.${r}`:`${n}/${s.difficulty}/${o}-${s.slug}/solution.${r}`}static formatSolutionHeader(e){const{problem:t,lang:s,runtime:i,memory:r,runtimePercentile:o,memoryPercentile:n}=e,c=`https://leetcode.com/problems/${t.slug}/`,m=t.topicTags.length>0?t.topicTags.join(", "):"N/A",a=["html","xml"].includes(this.getExtension(s))?"<!--":"#",g=["html","xml"].includes(this.getExtension(s))?"-->":"";return`${a} ──────────────────────────────────────────────────
${a} Problem  : ${t.id}. ${t.title}
${a} Difficulty: ${t.difficulty}
${a} Tags     : ${m}
${a} Link     : ${c}
${a} Runtime  : ${i} (beats ${o}%)
${a} Memory   : ${r} (beats ${n}%)
${a} Language : ${s}
${a} Synced by: leetie
${a} ────────────────────────────────────────────────── ${g}

${e.code}`}static async getFileSha(e,t,s,i,r){try{const o=await fetch(`${this.BASE_URL}/repos/${t}/${s}/contents/${i}?ref=${r}`,{headers:this.getHeaders(e)});if(o.ok)return(await o.json()).sha||null}catch(o){console.warn(`[leetie] Error checking SHA for ${i}:`,o)}return null}static async putFile(e,t,s,i,r,o,n,c,m){var w,E;const a=await this.getFileSha(e,t,s,i,n),g={message:o,content:this.toBase64(r),branch:n};if(a&&(g.sha=a),c){const d=m||"leetie-user",b=`${d.toLowerCase()}@users.noreply.github.com`,T={name:d,email:b,date:c};g.author=T,g.committer=T}const h=await fetch(`${this.BASE_URL}/repos/${t}/${s}/contents/${i}`,{method:"PUT",headers:this.getHeaders(e),body:JSON.stringify(g)});if(!h.ok){const d=await h.json().catch(()=>({})),b=d.message||d.error||`HTTP ${h.status}`;throw console.error(`[leetie] GitHub API PUT error (${h.status}) on ${i}:`,d),new Error(`GitHub API Error (${h.status}): ${b}`)}const $=await h.json();return((w=$.content)==null?void 0:w.sha)||((E=$.commit)==null?void 0:E.sha)||"success"}static generateReadmeContent(e,t){const s=t.solutionSubfolder||"solutions",i=e.map(r=>{const o=`https://leetcode.com/problems/${r.problemSlug}/`,n=`./${r.githubPath.replace(`${s}/`,"")}`,c=r.problemTitle.replace(/\|/g,"\\|");return`| ${r.problemSlug} | ${c} | ${r.difficulty} | ${r.lang} | [Problem](${o}) | [Solution](${n}) |`}).join(`
`);return`# My LeetCode Solutions

> *Automatically synced by [leetie](https://github.com/Shreeprasandh/leetie).*

## Progress Summary: ${e.length} Solved

| ID | Problem | Difficulty | Language | Problem Link | Solution Code |
|---|---------|-----------|----------|--------------|---------------|
${i}
`}static async commitSubmission(e){const t=await l.getConfig();if(!t.githubToken||!t.githubUsername)throw new Error("GitHub token or username not configured. Please open leetie options.");await f.ensureRepo(t.githubToken,t.githubUsername,t.repoName);const s=this.formatFilePath(e,t),i=t.addHeaderComment?this.formatSolutionHeader(e):e.code,r=`leetie: Add ${e.problem.id}. ${e.problem.title} [${e.problem.difficulty}] (${e.lang})`,o=e.timestamp?new Date(e.timestamp).toISOString():void 0,n=await this.putFile(t.githubToken,t.githubUsername,t.repoName,s,i,r,t.branch,o,t.githubUsername),c={submissionId:e.submissionId,problemSlug:e.problem.slug,problemTitle:e.problem.title,difficulty:e.problem.difficulty,commitSha:n,githubPath:s,committedAt:Date.now(),lang:e.lang},m=await l.addCommit(c);if(t.autoReadme)try{const a=`${t.solutionSubfolder||"solutions"}/README.md`,g=this.generateReadmeContent(m,t);await this.putFile(t.githubToken,t.githubUsername,t.repoName,a,g,"leetie: Update solutions index README",t.branch)}catch(a){console.warn("[leetie] Auto README update failed:",a)}return c}}y(S,"BASE_URL","https://api.github.com");class p{static stopRecovery(){this.isRunning=!1}static async fetchSubmissionList(e,t=20){var n;const i=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionList($offset: Int!, $limit: Int!) {
        submissionList(offset: $offset, limit: $limit) {
          hasNext
          submissions {
            id
            statusDisplay
            lang
            timestamp
            titleSlug
          }
        }
      }
    `,variables:{offset:e,limit:t}})});if(!i.ok)throw new Error(`LeetCode API request failed: ${i.statusText}`);const r=await i.json(),o=(n=r==null?void 0:r.data)==null?void 0:n.submissionList;return{submissions:(o==null?void 0:o.submissions)||[],hasNext:!!(o!=null&&o.hasNext)}}static async fetchSubmissionDetail(e,t){var m;const i=await fetch(this.LEETCODE_GRAPHQL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query:`
      query submissionDetails($id: Int!) {
        submissionDetails(submissionId: $id) {
          statusDisplay
          lang
          code
          runtime
          memory
          runtimePercentile
          memoryPercentile
          timestamp
          question {
            questionId
            title
            titleSlug
            difficulty
            topicTags {
              name
            }
          }
        }
      }
    `,variables:{id:Number(e)}})});if(!i.ok)return null;const r=await i.json(),o=(m=r==null?void 0:r.data)==null?void 0:m.submissionDetails;if(!o||o.statusDisplay!=="Accepted")return null;const n=o.question||{},c=Number(o.timestamp||t||0);return{submissionId:String(e),problem:{id:String(n.questionId||"0"),slug:n.titleSlug||"problem",title:n.title||"Problem",difficulty:n.difficulty||"Easy",topicTags:(n.topicTags||[]).map(a=>a.name||a)},lang:o.lang||"python3",code:o.code||"",runtime:o.runtime||"N/A",memory:o.memory||"N/A",runtimePercentile:Math.round(o.runtimePercentile||0),memoryPercentile:Math.round(o.memoryPercentile||0),timestamp:c>0?c*1e3:Date.now()}}static deduplicateSubmissions(e){const t=new Map;for(const s of e)if(s.statusDisplay==="Accepted"){const i=`${s.titleSlug}_${s.lang}`;t.has(i)||t.set(i,s)}return Array.from(t.values())}static async startRecovery(){if(!this.isRunning){this.isRunning=!0;try{const e=await l.getConfig();if(!e.githubToken||!e.githubUsername){await l.setState({syncStatus:"error",lastError:"GitHub Token or Username is missing. Please connect your GitHub account first.",recoveryProgress:null}),this.isRunning=!1;return}await l.setState({syncStatus:"recovering",lastError:null});const t=[];let s=0;const i=20;for(;this.isRunning;){const c=await this.fetchSubmissionList(s,i);if(t.push(...c.submissions),await l.setState({recoveryProgress:{current:t.length,total:t.length+(c.hasNext?i:0)}}),!c.hasNext)break;s+=i,await new Promise(m=>setTimeout(m,300))}if(!this.isRunning){await l.setState({syncStatus:"idle",recoveryProgress:null});return}const r=this.deduplicateSubmissions(t),o=r.length;let n=0;for(let c=0;c<o&&this.isRunning;c++){const m=r[c];await l.setState({recoveryProgress:{current:c+1,total:o}});try{const a=await this.fetchSubmissionDetail(m.id,m.timestamp);a&&(await S.commitSubmission(a),n++)}catch(a){console.warn(`[leetie] Failed to commit item ${m.id}:`,a),a.message&&a.message.includes("429")?(console.warn("[leetie] Rate limit encountered. Backing off for 5 seconds..."),await new Promise(g=>setTimeout(g,5e3))):await l.setState({lastError:`Commit error on #${m.titleSlug}: ${a.message}`})}await new Promise(a=>setTimeout(a,1e3))}await l.setState({syncStatus:"idle",recoveryProgress:null,lastError:n===0&&o>0?"Recovery completed but 0 commits succeeded. Please check GitHub permissions.":null})}catch(e){console.error("[leetie] History recovery error:",e),await l.setState({syncStatus:"error",lastError:e.message,recoveryProgress:null})}finally{this.isRunning=!1}}}}y(p,"LEETCODE_GRAPHQL","https://leetcode.com/graphql"),y(p,"isRunning",!1);console.log("[leetie] Background service worker initialized.");var P;typeof chrome<"u"&&((P=chrome.runtime)!=null&&P.onMessage)&&chrome.runtime.onMessage.addListener((u,e,t)=>{if(u.type==="GET_STATE")return l.getState().then(s=>t(s)),!0;if(u.type==="RECOVERY_START")return p.startRecovery(),t({success:!0,message:"History recovery started."}),!0;if(u.type==="RECOVERY_STOP")return p.stopRecovery(),t({success:!0,message:"History recovery stopped."}),!0;if(u.type==="TEST_CONNECTION"){const{token:s,repoName:i}=u.payload;return(async()=>{try{const r=await f.verifyUser(s);await l.setConfig({githubToken:s,githubUsername:r.login});const o=await f.ensureRepo(s,r.login,i);await l.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:r,repoOk:o})}catch(r){await l.setState({isAuthenticated:!1,lastError:r.message}),t({success:!1,error:r.message})}})(),!0}if(u.type==="START_OAUTH")return(async()=>{try{const s=await l.getConfig(),i=await R("Ov23li296L9RxwhuLXOv",s.proxyUrl),r=await f.verifyUser(i);await l.setConfig({githubToken:i,githubUsername:r.login}),await f.ensureRepo(i,r.login,s.repoName),await l.setState({isAuthenticated:!0,lastError:null}),t({success:!0,user:r})}catch(s){await l.setState({isAuthenticated:!1,lastError:s.message}),t({success:!1,error:s.message})}})(),!0;if(u.type==="FETCH_REPOS"){const{token:s}=u.payload;return f.getUserRepos(s).then(i=>t({success:!0,repos:i})).catch(i=>t({success:!1,error:i.message})),!0}if(u.type==="SUBMISSION_DETECTED"){const s=u.payload;return console.log("[leetie] Background worker orchestrating commit for:",s),(async()=>{try{await l.setState({syncStatus:"syncing"});const i=await S.commitSubmission(s);await l.setState({syncStatus:"idle",lastError:null}),typeof chrome<"u"&&chrome.notifications&&chrome.notifications.create({type:"basic",iconUrl:"assets/icon-48.png",title:"leetie — Solution Synced!",message:`Successfully committed ${s.problem.id}. ${s.problem.title} [${s.problem.difficulty}] to GitHub.`}),t({success:!0,record:i})}catch(i){await l.setState({syncStatus:"error",lastError:i.message}),t({success:!1,error:i.message})}})(),!0}return!1});
